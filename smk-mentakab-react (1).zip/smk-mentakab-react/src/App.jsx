import React, { useEffect, useMemo, useState } from 'react';
import { initializeApp } from 'firebase/app';
import {
  addDoc,
  collection,
  doc,
  getFirestore,
  onSnapshot,
  serverTimestamp,
  setDoc,
  updateDoc
} from 'firebase/firestore';
import {
  getAuth,
  onAuthStateChanged,
  signInAnonymously
} from 'firebase/auth';
import {
  Bell,
  BellRing,
  Calendar,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Eye,
  FileText,
  History,
  Lock,
  LogOut,
  RefreshCw,
  ShieldCheck,
  UploadCloud,
  UserCheck,
  Users,
  X
} from 'lucide-react';

const STAFF = [
  { id: 'pm1', name: "'Afifah Binti Abdul Aziz", category: 'makmal', role: 'Ketua Pembantu Makmal' },
  { id: 'pm2', name: 'Ida Zarina Binti Idris', category: 'makmal', role: 'Pembantu Makmal' },
  { id: 'pm3', name: 'Azian Binti Mohamad', category: 'makmal', role: 'Pembantu Makmal' },
  { id: 'pm4', name: 'Fatimah Binti Abdul Latiff', category: 'makmal', role: 'Pembantu Makmal' },
  { id: 'pm5', name: 'Zainun Binti Mohamed Ramthan', category: 'makmal', role: 'Pembantu Makmal' },
  { id: 'pm6', name: "Nor'aini Binti Md Yusoff", category: 'makmal', role: 'Pembantu Makmal' },
  { id: 'pm7', name: 'Fakarullah Amer Bin Zainal Abidin', category: 'makmal', role: 'Pembantu Makmal' },
  { id: 'pm8', name: 'Abdul Azam Bin Mohamed', category: 'makmal', role: 'Pembantu Makmal' },
  { id: 'pp1', name: 'Nor Faiza Binti Mustaffa Kamal', category: 'murid', role: 'PPM' },
  { id: 'pp2', name: 'Wan Azlena Binti Wan Deraman', category: 'murid', role: 'PPM' },
  { id: 'pp3', name: 'Mohd Faizal Bin Zainal', category: 'murid', role: 'PPM' },
  { id: 'pt1', name: 'Juhaida Binti Abd Rashid', category: 'tadbir', role: 'Ketua Pembantu Tadbir' },
  { id: 'pt2', name: 'Junainah Binti Hassan', category: 'tadbir', role: 'Pembantu Tadbir' },
  { id: 'pt3', name: 'Rafidah Binti Sidek', category: 'tadbir', role: 'Pembantu Tadbir' },
  { id: 'ka1', name: 'Muhammad Fahmi Bin Hamidin', category: 'am', role: 'PKA' },
  { id: 'ka2', name: 'Nursyaza Aina Binti Mohd Adaha', category: 'am', role: 'PKA' }
];

const CATEGORIES = {
  all: 'Semua',
  makmal: 'Pembantu Makmal',
  murid: 'PPM',
  tadbir: 'Pembantu Tadbir',
  am: 'PKA'
};

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

const hasFirebaseConfig = Object.values(firebaseConfig).every(Boolean);
const app = hasFirebaseConfig ? initializeApp(firebaseConfig) : null;
const db = app ? getFirestore(app) : null;
const auth = app ? getAuth(app) : null;

const APP_TITLE = 'Rekod Penghantaran Senarai Tugasan Harian';
const SCHOOL_NAME = 'Sekolah Menengah Kebangsaan Mentakab';
const PENGETUA = 'Hajah Aniza Binti Baharuddin';
const ADMIN_PASSCODE = import.meta.env.VITE_ADMIN_PASSCODE || '0000';
const PENGETUA_PASSCODE = import.meta.env.VITE_PENGETUA_PASSCODE || '1234';

function getInitials(name) {
  return name
    .split(' ')
    .map((part) => part[0])
    .filter(Boolean)
    .slice(0, 2)
    .join('')
    .toUpperCase();
}

function formatDate(date) {
  return new Intl.DateTimeFormat('ms-MY', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  }).format(date);
}

function getFirstMondayOfYear(year) {
  const date = new Date(year, 0, 1);
  while (date.getDay() !== 1) {
    date.setDate(date.getDate() + 1);
  }
  return date;
}

function getWeekRange(weekIndex) {
  const year = new Date().getFullYear();
  const firstMonday = getFirstMondayOfYear(year);
  const monday = new Date(firstMonday);
  monday.setDate(firstMonday.getDate() + weekIndex * 7);
  monday.setHours(0, 0, 0, 0);

  const friday = new Date(monday);
  friday.setDate(monday.getDate() + 4);
  friday.setHours(23, 59, 59, 999);

  return {
    monday,
    friday,
    key: `${year}-W${String(weekIndex + 1).padStart(2, '0')}`,
    label: `Minggu ${weekIndex + 1}`,
    fullLabel: `${formatDate(monday)} – ${formatDate(friday)}`
  };
}

function getCurrentWeekIndex() {
  const today = new Date();
  const year = today.getFullYear();
  const firstMonday = getFirstMondayOfYear(year);
  const diffMs = today - firstMonday;
  const week = Math.floor(diffMs / (1000 * 60 * 60 * 24 * 7));
  return Math.max(0, Math.min(51, week));
}

function getStatusMeta(submission) {
  if (!submission) {
    return { key: 'none', label: 'Belum Hantar', tone: 'slate' };
  }
  if (submission.status === 'verified') {
    return { key: 'verified', label: 'Disahkan', tone: 'green' };
  }
  if (submission.isLate) {
    return { key: 'late', label: 'Lewat', tone: 'red' };
  }
  return { key: 'submitted', label: 'Dihantar', tone: 'amber' };
}

function getToneStyles(tone) {
  const map = {
    slate: { bg: '#f1f5f9', text: '#475569', border: '#e2e8f0' },
    green: { bg: '#ecfdf5', text: '#047857', border: '#a7f3d0' },
    amber: { bg: '#fffbeb', text: '#b45309', border: '#fde68a' },
    red: { bg: '#fff1f2', text: '#be123c', border: '#fecdd3' },
    blue: { bg: '#eff6ff', text: '#1d4ed8', border: '#bfdbfe' }
  };
  return map[tone] || map.slate;
}

function PieRing({ verified, pending, late, total }) {
  const radius = 28;
  const circumference = 2 * Math.PI * radius;
  const safeTotal = total || 1;
  const verifiedArc = (verified / safeTotal) * circumference;
  const pendingArc = (pending / safeTotal) * circumference;
  const lateArc = (late / safeTotal) * circumference;

  return (
    <div style={{ position: 'relative', width: 120, height: 120 }}>
      <svg viewBox="0 0 80 80" width="120" height="120" style={{ transform: 'rotate(-90deg)' }}>
        <circle cx="40" cy="40" r={radius} fill="transparent" stroke="#e2e8f0" strokeWidth="10" />
        <circle cx="40" cy="40" r={radius} fill="transparent" stroke="#10b981" strokeWidth="10" strokeDasharray={`${verifiedArc} ${circumference}`} strokeDashoffset="0" strokeLinecap="round" />
        <circle cx="40" cy="40" r={radius} fill="transparent" stroke="#f59e0b" strokeWidth="10" strokeDasharray={`${pendingArc} ${circumference}`} strokeDashoffset={-verifiedArc} strokeLinecap="round" />
        <circle cx="40" cy="40" r={radius} fill="transparent" stroke="#e11d48" strokeWidth="10" strokeDasharray={`${lateArc} ${circumference}`} strokeDashoffset={-(verifiedArc + pendingArc)} strokeLinecap="round" />
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 24, fontWeight: 800, color: '#0f172a' }}>{verified}</div>
          <div style={{ fontSize: 11, color: '#64748b', fontWeight: 700 }}>Disahkan</div>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [user, setUser] = useState(null);
  const [loadingAuth, setLoadingAuth] = useState(true);
  const [currentWeekIdx, setCurrentWeekIdx] = useState(getCurrentWeekIndex());
  const [activeTab, setActiveTab] = useState('all');
  const [submissions, setSubmissions] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [schoolLogo, setSchoolLogo] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [toast, setToast] = useState(null);
  const [selectedStaff, setSelectedStaff] = useState(null);
  const [showViewer, setShowViewer] = useState(null);
  const [showNotifPanel, setShowNotifPanel] = useState(false);
  const [showLandingLogin, setShowLandingLogin] = useState(true);
  const [loginRole, setLoginRole] = useState('staff');
  const [loginStaffId, setLoginStaffId] = useState('');
  const [loginPasscode, setLoginPasscode] = useState('');
  const [loggedInStaff, setLoggedInStaff] = useState(null);
  const [uploadFile, setUploadFile] = useState(null);
  const [verifyNotes, setVerifyNotes] = useState('');
  const [busy, setBusy] = useState(false);

  const currentWeek = useMemo(() => getWeekRange(currentWeekIdx), [currentWeekIdx]);

  const filteredStaff = useMemo(() => {
    if (activeTab === 'all') return STAFF;
    return STAFF.filter((s) => s.category === activeTab);
  }, [activeTab]);

  const weekSubmissions = useMemo(
    () => submissions.filter((item) => item.weekKey === currentWeek.key),
    [submissions, currentWeek.key]
  );

  const stats = useMemo(() => {
    const verified = weekSubmissions.filter((s) => s.status === 'verified').length;
    const late = weekSubmissions.filter((s) => s.isLate && s.status !== 'verified').length;
    const submitted = weekSubmissions.filter((s) => s.status !== 'verified' && !s.isLate).length;
    const pending = Math.max(0, STAFF.length - weekSubmissions.length);
    return { verified, late, submitted, pending, total: STAFF.length };
  }, [weekSubmissions]);

  useEffect(() => {
    if (!toast) return undefined;
    const timer = setTimeout(() => setToast(null), 2800);
    return () => clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    if (!auth || !db) {
      setLoadingAuth(false);
      return;
    }

    let unsubAuth = () => {};
    let unsubSubs = () => {};
    let unsubNotif = () => {};
    let unsubSettings = () => {};

    signInAnonymously(auth)
      .catch((error) => {
        console.error(error);
        setToast({ type: 'error', message: 'Firebase gagal disambungkan. Sila semak konfigurasi.' });
      })
      .finally(() => {
        unsubAuth = onAuthStateChanged(auth, (firebaseUser) => {
          setUser(firebaseUser);
          setLoadingAuth(false);
        });
      });

    unsubSubs = onSnapshot(collection(db, 'submissions'), (snapshot) => {
      setSubmissions(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
    });

    unsubNotif = onSnapshot(collection(db, 'notifications'), (snapshot) => {
      const rows = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
      rows.sort((a, b) => {
        const ta = a.createdAt?.seconds || 0;
        const tb = b.createdAt?.seconds || 0;
        return tb - ta;
      });
      setNotifications(rows.slice(0, 20));
    });

    unsubSettings = onSnapshot(doc(db, 'settings', 'branding'), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setSchoolLogo(data.schoolLogo || '');
        setCoverImage(data.coverImage || '');
      }
    });

    return () => {
      unsubAuth();
      unsubSubs();
      unsubNotif();
      unsubSettings();
    };
  }, []);

  function showMessage(message, type = 'info') {
    setToast({ message, type });
  }

  async function addNotification(title, message, type = 'info') {
    if (!db) return;
    await addDoc(collection(db, 'notifications'), {
      title,
      message,
      type,
      createdAt: serverTimestamp()
    });
  }

  async function readAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  function canAccessStaff(staff) {
    if (!staff) return true;
    if (!showLandingLogin && !loggedInStaff) return true;
    if (!showLandingLogin && loggedInStaff) return loggedInStaff.id === staff.id;
    return true;
  }

  function handleOpenStaff(staff) {
    if (!canAccessStaff(staff) && !isAdminView()) {
      showMessage('Staff hanya boleh akses rekod sendiri.', 'error');
      return;
    }
    setSelectedStaff(staff);
    setUploadFile(null);
    setVerifyNotes('');
  }

  function isAdminView() {
    return !showLandingLogin && (loginRole === 'admin' || loginRole === 'pengetua');
  }

  function handleLandingLogin() {
    if (loginRole === 'staff') {
      if (!loginStaffId) {
        showMessage('Sila pilih nama staff.', 'error');
        return;
      }
      const selected = STAFF.find((s) => s.id === loginStaffId) || null;
      setLoggedInStaff(selected);
      setShowLandingLogin(false);
      setSelectedStaff(selected);
      showMessage(`Selamat datang, ${selected?.name || 'staff'}.`, 'success');
      return;
    }

    if (loginRole === 'admin') {
      if (loginPasscode !== ADMIN_PASSCODE) {
        showMessage('Kod Admin salah.', 'error');
        return;
      }
      setLoggedInStaff(null);
      setSelectedStaff(null);
      setShowLandingLogin(false);
      showMessage('Log masuk Admin berjaya.', 'success');
      return;
    }

    if (loginPasscode !== PENGETUA_PASSCODE) {
      showMessage('Kod Pengetua salah.', 'error');
      return;
    }
    setLoggedInStaff(null);
    setSelectedStaff(null);
    setShowLandingLogin(false);
    showMessage('Log masuk Pengetua berjaya.', 'success');
  }

  function handleLogout() {
    setShowLandingLogin(true);
    setLoginRole('staff');
    setLoginStaffId('');
    setLoginPasscode('');
    setLoggedInStaff(null);
    setSelectedStaff(null);
    setUploadFile(null);
    setVerifyNotes('');
    showMessage('Anda telah log keluar.', 'info');
  }

  async function handleUploadSubmission() {
    if (!selectedStaff) return;
    if (!db) {
      showMessage('Firebase belum dikonfigurasi.', 'error');
      return;
    }
    if (!uploadFile) {
      showMessage('Sila pilih fail dahulu.', 'error');
      return;
    }

    try {
      setBusy(true);
      const fileDataUrl = await readAsDataUrl(uploadFile);
      const now = new Date();
      const lateCutoff = new Date(currentWeek.friday);
      lateCutoff.setHours(23, 59, 59, 999);
      const payload = {
        staffId: selectedStaff.id,
        staffName: selectedStaff.name,
        category: selectedStaff.category,
        role: selectedStaff.role,
        weekKey: currentWeek.key,
        weekLabel: currentWeek.label,
        weekRange: currentWeek.fullLabel,
        fileName: uploadFile.name,
        fileType: uploadFile.type || 'application/octet-stream',
        fileDataUrl,
        submittedAt: now.toISOString(),
        status: 'submitted',
        verifiedAt: null,
        verifiedBy: null,
        verifyNotes: '',
        isLate: now > lateCutoff
      };

      await setDoc(doc(db, 'submissions', `${currentWeek.key}_${selectedStaff.id}`), payload);
      await addNotification(
        'Fail baharu dihantar',
        `${selectedStaff.name} menghantar fail bagi ${currentWeek.label}.`,
        'info'
      );
      setUploadFile(null);
      showMessage('Fail berjaya dihantar.', 'success');
    } catch (error) {
      console.error(error);
      showMessage('Gagal menghantar fail.', 'error');
    } finally {
      setBusy(false);
    }
  }

  async function handleVerifySubmission(submission) {
    if (!db || !submission) return;
    try {
      setBusy(true);
      await updateDoc(doc(db, 'submissions', submission.id), {
        status: 'verified',
        verifiedAt: new Date().toISOString(),
        verifiedBy: loginRole === 'pengetua' ? 'Pengetua' : 'Admin',
        verifyNotes: verifyNotes || ''
      });
      await addNotification(
        'Tugasan disahkan',
        `${submission.staffName} telah disahkan untuk ${submission.weekLabel}.`,
        'success'
      );
      setVerifyNotes('');
      showMessage('Tugasan berjaya disahkan.', 'success');
    } catch (error) {
      console.error(error);
      showMessage('Gagal mengesahkan tugasan.', 'error');
    } finally {
      setBusy(false);
    }
  }

  async function handleBrandingUpload(event, fieldName) {
    if (!db) {
      showMessage('Firebase belum dikonfigurasi.', 'error');
      return;
    }
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      setBusy(true);
      const dataUrl = await readAsDataUrl(file);
      const current = {
        schoolLogo,
        coverImage,
        [fieldName]: dataUrl
      };
      await setDoc(doc(db, 'settings', 'branding'), current, { merge: true });
      showMessage(`${fieldName === 'schoolLogo' ? 'Logo' : 'Banner'} berjaya dikemaskini.`, 'success');
    } catch (error) {
      console.error(error);
      showMessage('Gagal mengemaskini branding.', 'error');
    } finally {
      setBusy(false);
    }
  }

  function getSubmissionForStaff(staffId) {
    return weekSubmissions.find((row) => row.staffId === staffId);
  }

  const statsCards = [
    {
      title: 'Jumlah Staff',
      value: stats.total,
      icon: Users,
      tone: 'blue',
      names: STAFF.map((s) => s.name)
    },
    {
      title: 'Disahkan',
      value: stats.verified,
      icon: CheckCircle2,
      tone: 'green',
      names: weekSubmissions.filter((s) => s.status === 'verified').map((s) => s.staffName)
    },
    {
      title: 'Belum Hantar',
      value: stats.pending,
      icon: History,
      tone: 'amber',
      names: STAFF.filter((s) => !weekSubmissions.some((w) => w.staffId === s.id)).map((s) => s.name)
    },
    {
      title: 'Lewat',
      value: stats.late,
      icon: BellRing,
      tone: 'red',
      names: weekSubmissions.filter((s) => s.isLate && s.status !== 'verified').map((s) => s.staffName)
    }
  ];

  const pageBg = coverImage
    ? `linear-gradient(rgba(7, 23, 52, 0.70), rgba(7, 23, 52, 0.75)), url(${coverImage}) center/cover no-repeat`
    : 'linear-gradient(135deg, #0c2340 0%, #1e3a5f 40%, #6ec6ff 100%)';

  return (
    <div style={{ minHeight: '100vh', background: '#edf4ff', color: '#0f172a' }}>
      {showLandingLogin && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 1000, background: 'linear-gradient(135deg, #0b1f3a 0%, #163963 50%, #6fc9ff 100%)', display: 'grid', placeItems: 'center', padding: 20 }}>
          <div style={{ width: '100%', maxWidth: 1120, minHeight: 620, borderRadius: 36, overflow: 'hidden', boxShadow: '0 30px 80px rgba(15,23,42,.35)', background: '#fff', display: 'grid', gridTemplateColumns: '1.05fr 0.95fr' }}>
            <div style={{ padding: 48, color: 'white', background: 'linear-gradient(135deg, rgba(13,38,73,0.98), rgba(30,58,95,0.95))', position: 'relative' }}>
              <div style={{ position: 'absolute', inset: 0, background: coverImage ? `linear-gradient(rgba(10,27,51,.72), rgba(10,27,51,.72)), url(${coverImage}) center/cover` : 'transparent' }} />
              <div style={{ position: 'relative', zIndex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', height: '100%' }}>
                <div>
                  <div style={{ width: 100, height: 100, borderRadius: 28, background: 'rgba(255,255,255,.12)', display: 'grid', placeItems: 'center', overflow: 'hidden', backdropFilter: 'blur(12px)', border: '1px solid rgba(255,255,255,.15)' }}>
                    {schoolLogo ? (
                      <img src={schoolLogo} alt="Logo sekolah" style={{ width: '100%', height: '100%', objectFit: 'contain', background: 'white' }} />
                    ) : (
                      <div style={{ fontWeight: 800, fontSize: 28 }}>SMK</div>
                    )}
                  </div>
                  <div style={{ marginTop: 28, fontSize: 42, lineHeight: 1.05, fontWeight: 800, maxWidth: 520 }}>
                    {APP_TITLE}
                  </div>
                  <div style={{ marginTop: 16, fontSize: 15, opacity: 0.9, fontWeight: 700, letterSpacing: '.12em', textTransform: 'uppercase' }}>
                    {SCHOOL_NAME}
                  </div>
                  <div style={{ marginTop: 26, background: 'rgba(255,255,255,.10)', border: '1px solid rgba(255,255,255,.14)', padding: 22, borderRadius: 22, maxWidth: 420 }}>
                    <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '.18em', color: '#facc15', fontWeight: 800 }}>Pengetua</div>
                    <div style={{ marginTop: 8, fontSize: 22, fontWeight: 800 }}>{PENGETUA}</div>
                  </div>
                </div>
                <div style={{ fontSize: 12, opacity: 0.92, fontWeight: 700, letterSpacing: '.12em', textTransform: 'uppercase' }}>
                  Rekod mingguan • upload fail • semakan • notifikasi
                </div>
              </div>
            </div>

            <div style={{ padding: '42px 36px', background: '#f8fbff', display: 'grid', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 12, fontWeight: 800, letterSpacing: '.2em', textTransform: 'uppercase', color: '#3b82f6' }}>Log masuk</div>
                <div style={{ marginTop: 10, fontSize: 34, fontWeight: 800, color: '#1e3a5f' }}>Selamat Datang</div>
                <div style={{ marginTop: 8, color: '#64748b', fontWeight: 600 }}>Pilih jenis akses untuk masuk ke sistem.</div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginTop: 28 }}>
                  {['staff', 'admin', 'pengetua'].map((role) => {
                    const active = loginRole === role;
                    return (
                      <button
                        key={role}
                        onClick={() => {
                          setLoginRole(role);
                          setLoginPasscode('');
                          setLoginStaffId('');
                        }}
                        style={{
                          border: active ? '1px solid #1e3a5f' : '1px solid #dbeafe',
                          background: active ? '#1e3a5f' : 'white',
                          color: active ? 'white' : '#475569',
                          padding: '16px 10px',
                          borderRadius: 18,
                          fontWeight: 800,
                          textTransform: 'uppercase',
                          letterSpacing: '.08em',
                          cursor: 'pointer'
                        }}
                      >
                        {role}
                      </button>
                    );
                  })}
                </div>

                {loginRole === 'staff' ? (
                  <div style={{ marginTop: 24 }}>
                    <label style={{ display: 'block', fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '.16em', color: '#64748b', marginBottom: 10 }}>Pilih nama staff</label>
                    <select
                      value={loginStaffId}
                      onChange={(e) => setLoginStaffId(e.target.value)}
                      style={{ width: '100%', padding: '18px 18px', borderRadius: 18, border: '2px solid #dbeafe', outline: 'none', fontSize: 14, fontWeight: 700, color: '#1e293b', background: 'white' }}
                    >
                      <option value="">-- Sila pilih nama --</option>
                      {STAFF.map((staff) => (
                        <option key={staff.id} value={staff.id}>{staff.name} — {staff.role}</option>
                      ))}
                    </select>
                    <button onClick={handleLandingLogin} style={{ width: '100%', marginTop: 18, padding: '18px 16px', borderRadius: 18, border: 'none', background: '#1e3a5f', color: 'white', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '.16em', cursor: 'pointer' }}>
                      Masuk sebagai staff
                    </button>
                  </div>
                ) : (
                  <div style={{ marginTop: 24 }}>
                    <label style={{ display: 'block', fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '.16em', color: '#64748b', marginBottom: 10 }}>Kod akses</label>
                    <input
                      type="password"
                      maxLength={4}
                      value={loginPasscode}
                      onChange={(e) => setLoginPasscode(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleLandingLogin()}
                      placeholder="****"
                      style={{ width: '100%', padding: '18px 18px', borderRadius: 18, border: '2px solid #dbeafe', outline: 'none', fontSize: 30, letterSpacing: '0.5em', fontWeight: 800, textAlign: 'center', color: '#1e3a5f', background: 'white' }}
                    />
                    <button onClick={handleLandingLogin} style={{ width: '100%', marginTop: 18, padding: '18px 16px', borderRadius: 18, border: 'none', background: '#1e3a5f', color: 'white', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '.16em', cursor: 'pointer' }}>
                      {loginRole === 'admin' ? 'Masuk sebagai admin' : 'Masuk sebagai pengetua'}
                    </button>
                  </div>
                )}

                <div style={{ marginTop: 22, padding: 18, borderRadius: 18, background: '#eff6ff', border: '1px solid #dbeafe' }}>
                  <div style={{ fontWeight: 800, fontSize: 12, textTransform: 'uppercase', letterSpacing: '.16em', color: '#2563eb' }}>Maklumat akses</div>
                  <div style={{ marginTop: 10, color: '#475569', fontWeight: 700, fontSize: 14, lineHeight: 1.8 }}>
                    <div>Staff: pilih nama sendiri</div>
                    <div>Admin: kod default <b>{ADMIN_PASSCODE}</b></div>
                    <div>Pengetua: kod default <b>{PENGETUA_PASSCODE}</b></div>
                  </div>
                </div>

                {!hasFirebaseConfig && (
                  <div style={{ marginTop: 18, padding: 16, borderRadius: 18, background: '#fff7ed', border: '1px solid #fed7aa', color: '#9a3412', fontWeight: 700, fontSize: 13 }}>
                    Firebase belum dikonfigurasi. Isi fail <b>.env</b> dahulu.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      <section style={{ background: pageBg, color: 'white', padding: '28px 22px 38px' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 18, alignItems: 'flex-start', flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', gap: 18, alignItems: 'center' }}>
              <div style={{ width: 88, height: 88, borderRadius: 24, background: 'rgba(255,255,255,.1)', border: '1px solid rgba(255,255,255,.16)', display: 'grid', placeItems: 'center', overflow: 'hidden' }}>
                {schoolLogo ? <img src={schoolLogo} alt="logo" style={{ width: '100%', height: '100%', objectFit: 'contain', background: 'white' }} /> : <div style={{ fontWeight: 800, fontSize: 26 }}>SMK</div>}
              </div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '.18em', color: '#bfdbfe' }}>{currentWeek.label}</div>
                <h1 style={{ margin: '8px 0 8px', fontSize: 36, lineHeight: 1.05 }}>{APP_TITLE}</h1>
                <div style={{ fontSize: 16, fontWeight: 700 }}>{SCHOOL_NAME}</div>
                <div style={{ marginTop: 4, color: '#dbeafe', fontWeight: 600 }}>Pengetua: {PENGETUA}</div>
                <div style={{ marginTop: 8, display: 'inline-flex', padding: '9px 14px', borderRadius: 999, background: 'rgba(255,255,255,.12)', border: '1px solid rgba(255,255,255,.15)', fontWeight: 700, fontSize: 13, gap: 8, alignItems: 'center' }}>
                  <Calendar size={15} /> {currentWeek.fullLabel}
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'rgba(255,255,255,.1)', padding: '12px 16px', borderRadius: 18, border: '1px solid rgba(255,255,255,.12)', fontWeight: 700, fontSize: 13 }}>
                <UserCheck size={16} />
                {isAdminView() ? `Akses: ${loginRole === 'pengetua' ? 'Pengetua' : 'Admin'}` : loggedInStaff ? `Staff: ${loggedInStaff.name}` : 'Akses belum dipilih'}
              </div>
              <button onClick={() => setShowNotifPanel((v) => !v)} style={headerBtnStyle()}>
                <Bell size={16} /> Notifikasi
              </button>
              {isAdminView() && (
                <label style={headerBtnStyle('label')}>
                  <ShieldCheck size={16} /> Ubah Logo
                  <input type="file" accept="image/*" hidden onChange={(e) => handleBrandingUpload(e, 'schoolLogo')} />
                </label>
              )}
              {isAdminView() && (
                <label style={headerBtnStyle('label')}>
                  <RefreshCw size={16} /> Ubah Banner
                  <input type="file" accept="image/*" hidden onChange={(e) => handleBrandingUpload(e, 'coverImage')} />
                </label>
              )}
              <button onClick={handleLogout} style={headerBtnStyle()}>
                <LogOut size={16} /> Log Keluar
              </button>
            </div>
          </div>
        </div>
      </section>

      <main style={{ maxWidth: 1280, margin: '0 auto', padding: '24px 18px 48px' }}>
        {showNotifPanel && (
          <div style={{ background: 'white', border: '1px solid #dbeafe', borderRadius: 28, boxShadow: '0 15px 40px rgba(15,23,42,.08)', padding: 22, marginBottom: 22 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ margin: 0, fontSize: 18, display: 'flex', gap: 10, alignItems: 'center' }}><BellRing size={18} /> Notifikasi Terkini</h3>
              <button onClick={() => setShowNotifPanel(false)} style={iconGhostStyle}><X size={16} /></button>
            </div>
            <div style={{ display: 'grid', gap: 12 }}>
              {notifications.length === 0 ? (
                <div style={{ color: '#64748b', fontWeight: 600 }}>Tiada notifikasi lagi.</div>
              ) : notifications.map((item) => (
                <div key={item.id} style={{ border: '1px solid #e2e8f0', borderRadius: 18, padding: 16, background: '#f8fbff' }}>
                  <div style={{ fontWeight: 800 }}>{item.title}</div>
                  <div style={{ marginTop: 6, color: '#475569', fontWeight: 600 }}>{item.message}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        <section style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1.4fr) minmax(280px, .8fr)', gap: 22, alignItems: 'stretch' }}>
          <div style={{ background: 'white', borderRadius: 30, border: '1px solid #dbeafe', boxShadow: '0 15px 40px rgba(15,23,42,.08)', padding: 24 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 12, fontWeight: 800, letterSpacing: '.18em', color: '#3b82f6', textTransform: 'uppercase' }}>Semakan mingguan</div>
                <h2 style={{ margin: '8px 0 0', fontSize: 26 }}>Ringkasan Status</h2>
              </div>
              <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
                <button onClick={() => setCurrentWeekIdx((v) => Math.max(0, v - 1))} style={navBtnStyle}><ChevronLeft size={18} /></button>
                <div style={{ padding: '12px 18px', borderRadius: 18, background: '#eff6ff', color: '#1e3a5f', fontWeight: 800 }}>{currentWeek.label}</div>
                <button onClick={() => setCurrentWeekIdx((v) => Math.min(51, v + 1))} style={navBtnStyle}><ChevronRight size={18} /></button>
              </div>
            </div>

            <div style={{ marginTop: 22, display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: 14 }}>
              {statsCards.map((card) => {
                const tone = getToneStyles(card.tone);
                const Icon = card.icon;
                return (
                  <div key={card.title} style={{ padding: 18, borderRadius: 24, border: `1px solid ${tone.border}`, background: tone.bg }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
                      <div style={{ color: tone.text, fontWeight: 800, fontSize: 12, textTransform: 'uppercase', letterSpacing: '.14em' }}>{card.title}</div>
                      <Icon size={18} color={tone.text} />
                    </div>
                    <div style={{ marginTop: 12, fontSize: 34, fontWeight: 800, color: '#0f172a' }}>{card.value}</div>
                    <div style={{ marginTop: 8, fontSize: 13, color: '#475569', fontWeight: 600 }}>{card.names.length ? `${card.names.slice(0, 2).join(', ')}${card.names.length > 2 ? '...' : ''}` : 'Tiada rekod'}</div>
                  </div>
                );
              })}
            </div>
          </div>

          <div style={{ background: 'white', borderRadius: 30, border: '1px solid #dbeafe', boxShadow: '0 15px 40px rgba(15,23,42,.08)', padding: 24, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap' }}>
            <PieRing verified={stats.verified} pending={stats.pending + stats.submitted} late={stats.late} total={stats.total} />
            <div style={{ flex: 1, minWidth: 180 }}>
              <div style={{ fontSize: 12, fontWeight: 800, letterSpacing: '.18em', color: '#3b82f6', textTransform: 'uppercase' }}>Carta pai ringkas</div>
              <div style={{ marginTop: 8, fontSize: 24, fontWeight: 800 }}>Prestasi Minggu Ini</div>
              <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
                <Legend color="#10b981" label={`Disahkan: ${stats.verified}`} />
                <Legend color="#f59e0b" label={`Belum disahkan / belum hantar: ${stats.pending + stats.submitted}`} />
                <Legend color="#e11d48" label={`Lewat: ${stats.late}`} />
              </div>
            </div>
          </div>
        </section>

        <section style={{ marginTop: 22, background: 'white', borderRadius: 30, border: '1px solid #dbeafe', boxShadow: '0 15px 40px rgba(15,23,42,.08)', padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
            <div>
              <div style={{ fontSize: 12, fontWeight: 800, letterSpacing: '.18em', color: '#3b82f6', textTransform: 'uppercase' }}>Direktori staff</div>
              <h2 style={{ margin: '8px 0 0', fontSize: 28 }}>Senarai Staff</h2>
            </div>
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              {Object.entries(CATEGORIES).map(([key, label]) => (
                <button key={key} onClick={() => setActiveTab(key)} style={{ ...tabStyle, background: activeTab === key ? '#1e3a5f' : '#f8fbff', color: activeTab === key ? 'white' : '#334155', border: activeTab === key ? '1px solid #1e3a5f' : '1px solid #dbeafe' }}>
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div style={{ marginTop: 18, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(255px, 1fr))', gap: 16 }}>
            {filteredStaff.map((staff) => {
              const submission = getSubmissionForStaff(staff.id);
              const status = getStatusMeta(submission);
              const tone = getToneStyles(status.tone);
              const locked = !isAdminView() && loggedInStaff && loggedInStaff.id !== staff.id;
              return (
                <div key={staff.id} onClick={() => handleOpenStaff(staff)} style={{ borderRadius: 26, border: locked ? '1px dashed #cbd5e1' : '1px solid #dbeafe', background: locked ? '#f8fafc' : 'white', padding: 18, cursor: 'pointer', boxShadow: '0 10px 30px rgba(15,23,42,.05)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'start' }}>
                    <div style={{ display: 'flex', gap: 12 }}>
                      <div style={{ width: 54, height: 54, borderRadius: 18, background: '#eff6ff', color: '#1e3a5f', display: 'grid', placeItems: 'center', fontWeight: 800 }}>{getInitials(staff.name)}</div>
                      <div>
                        <div style={{ fontWeight: 800, lineHeight: 1.3 }}>{staff.name}</div>
                        <div style={{ color: '#64748b', fontSize: 13, marginTop: 4, fontWeight: 600 }}>{staff.role}</div>
                      </div>
                    </div>
                    {locked && <Lock size={16} color="#94a3b8" />}
                  </div>
                  <div style={{ marginTop: 14, display: 'inline-flex', padding: '7px 12px', borderRadius: 999, background: tone.bg, color: tone.text, border: `1px solid ${tone.border}`, fontWeight: 800, fontSize: 12 }}>{status.label}</div>
                  <div style={{ marginTop: 12, color: '#475569', fontWeight: 600, fontSize: 13 }}>
                    {submission ? `Fail: ${submission.fileName}` : 'Belum ada penghantaran untuk minggu ini.'}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </main>

      {selectedStaff && (
        <div style={overlayStyle}>
          <div style={modalStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'start' }}>
              <div>
                <div style={{ fontSize: 12, fontWeight: 800, letterSpacing: '.18em', color: '#3b82f6', textTransform: 'uppercase' }}>Rekod staff</div>
                <div style={{ marginTop: 8, fontSize: 28, fontWeight: 800 }}>{selectedStaff.name}</div>
                <div style={{ marginTop: 6, color: '#64748b', fontWeight: 600 }}>{selectedStaff.role} • {currentWeek.fullLabel}</div>
              </div>
              <button onClick={() => setSelectedStaff(null)} style={iconGhostStyle}><X size={18} /></button>
            </div>

            {(() => {
              const submission = getSubmissionForStaff(selectedStaff.id);
              const status = getStatusMeta(submission);
              const tone = getToneStyles(status.tone);
              return (
                <div style={{ marginTop: 22 }}>
                  <div style={{ display: 'inline-flex', padding: '9px 14px', borderRadius: 999, background: tone.bg, color: tone.text, border: `1px solid ${tone.border}`, fontWeight: 800, fontSize: 12 }}>{status.label}</div>

                  {submission && (
                    <div style={{ marginTop: 18, border: '1px solid #dbeafe', borderRadius: 24, padding: 18, background: '#f8fbff' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
                        <div>
                          <div style={{ fontWeight: 800, fontSize: 18 }}>{submission.fileName}</div>
                          <div style={{ marginTop: 6, color: '#64748b', fontWeight: 600, fontSize: 14 }}>Tarikh hantar: {new Date(submission.submittedAt).toLocaleString('ms-MY')}</div>
                          {submission.verifiedBy && (
                            <div style={{ marginTop: 4, color: '#0f766e', fontWeight: 700, fontSize: 14 }}>Disahkan oleh: {submission.verifiedBy}</div>
                          )}
                        </div>
                        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                          <button onClick={() => setShowViewer(submission)} style={primarySmallBtn}><Eye size={16} /> Pratonton</button>
                        </div>
                      </div>

                      {isAdminView() && submission.status !== 'verified' && (
                        <div style={{ marginTop: 18, borderTop: '1px solid #dbeafe', paddingTop: 18 }}>
                          <label style={{ display: 'block', fontWeight: 800, fontSize: 12, textTransform: 'uppercase', letterSpacing: '.14em', color: '#64748b', marginBottom: 10 }}>Catatan semakan</label>
                          <textarea value={verifyNotes} onChange={(e) => setVerifyNotes(e.target.value)} rows={4} placeholder="Contoh: Dokumen lengkap dan diterima." style={textAreaStyle} />
                          <button onClick={() => handleVerifySubmission(submission)} style={{ ...primaryActionBtn, marginTop: 12 }} disabled={busy}>
                            <ShieldCheck size={18} /> {busy ? 'Sedang proses...' : 'Sahkan Tugasan'}
                          </button>
                        </div>
                      )}
                    </div>
                  )}

                  {(!submission && (isAdminView() || loggedInStaff?.id === selectedStaff.id)) && (
                    <div style={{ marginTop: 18, border: '1px dashed #bfdbfe', borderRadius: 24, padding: 18, background: '#f8fbff' }}>
                      <div style={{ fontWeight: 800, fontSize: 18 }}>Muat Naik Tugasan Mingguan</div>
                      <div style={{ marginTop: 8, color: '#64748b', fontWeight: 600 }}>Fail boleh dipratonton terus selepas dihantar.</div>
                      <label style={{ marginTop: 16, display: 'block', border: '2px dashed #93c5fd', borderRadius: 22, background: 'white', padding: 20, cursor: 'pointer' }}>
                        <input type="file" hidden onChange={(e) => setUploadFile(e.target.files?.[0] || null)} />
                        <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
                          <div style={{ width: 52, height: 52, borderRadius: 18, background: '#eff6ff', display: 'grid', placeItems: 'center', color: '#2563eb' }}><UploadCloud size={22} /></div>
                          <div>
                            <div style={{ fontWeight: 800 }}>{uploadFile ? uploadFile.name : 'Klik untuk pilih fail'}</div>
                            <div style={{ color: '#64748b', fontWeight: 600, fontSize: 13, marginTop: 4 }}>PDF, imej, atau dokumen lain</div>
                          </div>
                        </div>
                      </label>
                      <button onClick={handleUploadSubmission} style={{ ...primaryActionBtn, marginTop: 16 }} disabled={busy}>
                        <UploadCloud size={18} /> {busy ? 'Sedang memuat naik...' : 'Hantar Tugasan'}
                      </button>
                    </div>
                  )}
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {showViewer && (
        <div style={overlayStyle}>
          <div style={{ ...modalStyle, maxWidth: 1100, minHeight: 600 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'center', marginBottom: 16 }}>
              <div>
                <div style={{ fontSize: 12, fontWeight: 800, letterSpacing: '.18em', color: '#3b82f6', textTransform: 'uppercase' }}>Pratonton fail</div>
                <div style={{ marginTop: 6, fontSize: 22, fontWeight: 800 }}>{showViewer.fileName}</div>
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <a href={showViewer.fileDataUrl} download={showViewer.fileName} style={{ ...primarySmallBtn, textDecoration: 'none' }}><FileText size={16} /> Muat turun</a>
                <button onClick={() => setShowViewer(null)} style={iconGhostStyle}><X size={18} /></button>
              </div>
            </div>
            <div style={{ border: '1px solid #dbeafe', borderRadius: 24, overflow: 'hidden', background: '#f8fbff', minHeight: 460 }}>
              {showViewer.fileType?.startsWith('image/') ? (
                <img src={showViewer.fileDataUrl} alt={showViewer.fileName} style={{ width: '100%', display: 'block', objectFit: 'contain', maxHeight: 700, background: '#f8fafc' }} />
              ) : showViewer.fileType === 'application/pdf' ? (
                <iframe title={showViewer.fileName} src={showViewer.fileDataUrl} style={{ width: '100%', height: 700, border: 'none' }} />
              ) : (
                <div style={{ padding: 30 }}>
                  <div style={{ fontWeight: 800, fontSize: 20 }}>Pratonton terhad untuk fail ini.</div>
                  <div style={{ marginTop: 10, color: '#64748b', fontWeight: 600 }}>Fail jenis ini tidak boleh dipaparkan terus dalam pelayar. Gunakan butang muat turun.</div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div style={{ position: 'fixed', right: 18, bottom: 18, zIndex: 1200, background: toast.type === 'error' ? '#7f1d1d' : toast.type === 'success' ? '#065f46' : '#0f172a', color: 'white', padding: '14px 18px', borderRadius: 18, boxShadow: '0 16px 40px rgba(15,23,42,.2)', fontWeight: 700 }}>
          {toast.message}
        </div>
      )}

      {loadingAuth && hasFirebaseConfig && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,.36)', display: 'grid', placeItems: 'center', zIndex: 1300 }}>
          <div style={{ padding: '18px 22px', borderRadius: 20, background: 'white', fontWeight: 800 }}>Menyambung ke Firebase...</div>
        </div>
      )}

      <style>{responsiveCss}</style>
    </div>
  );
}

function Legend({ color, label }) {
  return (
    <div style={{ display: 'flex', gap: 10, alignItems: 'center', fontWeight: 700, color: '#334155' }}>
      <span style={{ width: 12, height: 12, borderRadius: 999, background: color, display: 'inline-block' }} />
      <span>{label}</span>
    </div>
  );
}

const tabStyle = {
  padding: '11px 16px',
  borderRadius: 14,
  fontWeight: 800,
  cursor: 'pointer'
};

function headerBtnStyle(asLabel) {
  return {
    display: 'inline-flex',
    gap: 8,
    alignItems: 'center',
    background: 'rgba(255,255,255,.1)',
    border: '1px solid rgba(255,255,255,.14)',
    color: 'white',
    padding: '12px 16px',
    borderRadius: 16,
    cursor: 'pointer',
    fontWeight: 700,
    fontSize: 13,
    textDecoration: 'none'
  };
}

const navBtnStyle = {
  width: 44,
  height: 44,
  borderRadius: 14,
  border: '1px solid #dbeafe',
  background: 'white',
  display: 'grid',
  placeItems: 'center',
  cursor: 'pointer'
};

const primarySmallBtn = {
  display: 'inline-flex',
  gap: 8,
  alignItems: 'center',
  padding: '11px 14px',
  borderRadius: 14,
  border: 'none',
  background: '#1e3a5f',
  color: 'white',
  fontWeight: 800,
  cursor: 'pointer'
};

const primaryActionBtn = {
  display: 'inline-flex',
  gap: 8,
  alignItems: 'center',
  justifyContent: 'center',
  width: '100%',
  padding: '15px 16px',
  borderRadius: 16,
  border: 'none',
  background: '#1e3a5f',
  color: 'white',
  fontWeight: 800,
  cursor: 'pointer'
};

const textAreaStyle = {
  width: '100%',
  padding: 14,
  borderRadius: 16,
  border: '1px solid #cbd5e1',
  resize: 'vertical',
  fontFamily: 'inherit',
  outline: 'none'
};

const overlayStyle = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(15,23,42,.42)',
  display: 'grid',
  placeItems: 'center',
  zIndex: 1100,
  padding: 18
};

const modalStyle = {
  width: '100%',
  maxWidth: 760,
  maxHeight: '92vh',
  overflow: 'auto',
  background: 'white',
  borderRadius: 30,
  padding: 24,
  boxShadow: '0 30px 80px rgba(15,23,42,.25)'
};

const iconGhostStyle = {
  width: 42,
  height: 42,
  borderRadius: 14,
  border: '1px solid #dbeafe',
  background: '#f8fbff',
  display: 'grid',
  placeItems: 'center',
  cursor: 'pointer'
};

const responsiveCss = `
  @media (max-width: 1080px) {
    section[style*="grid-template-columns: 1.05fr 0.95fr"] { grid-template-columns: 1fr !important; }
  }
  @media (max-width: 980px) {
    section[style*="grid-template-columns: minmax(0, 1.4fr) minmax(280px, .8fr)"] { grid-template-columns: 1fr !important; }
  }
  @media (max-width: 860px) {
    div[style*="grid-template-columns: repeat(4, minmax(0, 1fr))"] { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
  }
  @media (max-width: 720px) {
    div[style*="grid-template-columns: repeat(3, 1fr)"] { grid-template-columns: 1fr !important; }
    h1 { font-size: 28px !important; }
    h2 { font-size: 22px !important; }
  }
  @media (max-width: 560px) {
    div[style*="grid-template-columns: repeat(4, minmax(0, 1fr))"] { grid-template-columns: 1fr !important; }
    main { padding-left: 12px !important; padding-right: 12px !important; }
  }
`;

export default App;
